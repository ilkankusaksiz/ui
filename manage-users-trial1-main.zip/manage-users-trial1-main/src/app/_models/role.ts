export enum Role {
    Guest = 'Guest',
    Admin = 'Admin',
    SuperAdmin = 'SuperAdmin'
}